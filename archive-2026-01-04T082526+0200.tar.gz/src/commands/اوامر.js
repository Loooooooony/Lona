const { EmbedBuilder } = require('discord.js');
const config = require('../../config.js');

module.exports = {
    name: 'اوامر',
    description: 'عرض جميع الحيل وطرق العيش المتاحة',
    async execute(message) {
        try {
            const embed = new EmbedBuilder()
                .setTitle(config.commandsListTitle || '📜 دليل البقاء في الشارع 📜')
                .setDescription(config.commandsListDescription || 'هذه هي الطرق المتاحة عشان تعيش وتجمع قواطي 🥫:')
                .setColor(config.embedColor || '#59483b') // لون بني (كرتونة)
                .addFields(
                    // ---------------- قسم التجميع (الكادحين) ----------------
                    { name: '🥫 جدي', value: 'مد إيدك بالتقاطع واسترزق (الراتب اليومي).', inline: true },
                    { name: '🛠️ مهنة', value: 'اختار شغلة (كار) جديدة تزيد يوميتك.', inline: true },
                    { name: '🎁 يومي', value: 'استلم الحصة التموينية (هدية يومية).', inline: true },
                    
                    // ---------------- قسم التجارة والمخاطرة ----------------
                    { name: '📉 سوق [كل | نص | ربع]', value: 'تاجر بالخردة بالسوك (ربح وخسارة).', inline: true },
                    { name: '💼 تشغيل [كل | نص | ربع]', value: 'شغل قواطيك عند واحد (استثمار).', inline: true },
                    { name: '🎟️ يانصيب', value: 'اشتري ورقة، يا تصيب يا تخيب.', inline: true },
                    { name: '🎲 زار [كل | نص | ربع]', value: 'العب زار وية الجماعة عالحصيرة.', inline: true },
                    { name: '🐓 رهان [كل | نص | ربع]', value: 'راهن بقواطيك على مصارعة ديچة.', inline: true },

                    // ---------------- قسم العقارات والبسطيات ----------------
                    { name: '⛺ منامات', value: 'شوف قائمة أماكن النوم (الكراتين والهياكل).', inline: true },
                    { name: '🛌 حجز [رقم]', value: 'احجز مكان تنام بيه من القائمة.', inline: true },
                    { name: '🛒 بسطيات', value: 'شوف البسطيات المعروضة للبيع.', inline: true },
                    { name: '🏷️ شراء_بسطية [رقم]', value: 'اشتري بسطية واسترزق منها.', inline: true },
                    { name: '🤝 بيع_بسطية @مستخدم [سعر]', value: 'بيع بسطيتك لواحد ثاني.', inline: true },
                    { name: '💰 وارد', value: 'لم الغلة (الأرباح) من بسطياتك.', inline: true },

                    // ---------------- قسم العصابات والديون ----------------
                    { name: '💸 داين', value: 'اطلب سلفة من "أبو المولدة".', inline: true },
                    { name: '🚪 توفي', value: 'سدد ديونك واخلص من الديانة.', inline: true },
                    { name: '🤝 قطة @المستخدم [المبلغ]', value: 'حول قواطي لصاحبك (أو ادفع خاوة).', inline: true },
                    { name: '🏃 قفط @المستخدم', value: 'حاول تبوك كرتونة واحد نايم (نهب).', inline: true },
                    { name: '🐕 كلب [ساعات]', value: 'أجر كلب ضال يحميك من السرقة.', inline: true },

                    // ---------------- قسم المعلومات ----------------
                    { name: '🎒 فلوسي', value: 'شوف شكد عندك قواطي (رصيد).', inline: true }, // أو "فلوسي" حسب ملفك
                    { name: '🏆 الزناكيل', value: 'قائمة أباطرة الزبالة (الأغنياء).', inline: true },
                    { name: '🆔 هويتي', value: 'معلومات عن تاريخك "المشرف".', inline: true },
                    { name: '⏳ وقت', value: 'شوف شكد باقي وقت حتى تعيد الحيل.', inline: true }
                )
                .setFooter({ text: `المنادي: ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();

            message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error in اوامر command:', error);
            message.reply('حدث خطأ، القائمة انشقت!');
        }
    }
};
